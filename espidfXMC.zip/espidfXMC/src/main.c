/*
 * SPDX-FileCopyrightText: 2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 */
/* SR lock Example (currently only for XMC)

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "xmc_lock_sr.h"
#include "inttypes.h"

void app_main(void)
{
    /*
     * Call this at the beginning of your app.
     * - If permanent==false, the SR will be locked after this line is executed and until power down.
     * - If permanent==true, the SR will be locked to a specific value forever.
     *          This is irreversible even after power down.
     *          Please do read readme before doing this.
     *
     * CAUTION: This may avoid further usage of HFM mode (> 80Mhz). Only call this when you are sure this device will not run above 80MHz.
     */
    printf("Hello world!\n");
    uint32_t flash_id ;
    uint32_t sfdp_04, sfdp_06;
    printf("chipid: %6"SCNx32"\n", flash_id);
    // doesn't work after this command:
    //spi_flash_disable_interrupts_caches_and_other_cpu();
    xmc_read_flash_id(&flash_id, (uint8_t*)&sfdp_04, (uint8_t*)&sfdp_06);
    //spi_flash_enable_interrupts_caches_and_other_cpu();
    printf("chipid: %6"SCNx32"\n", flash_id);

    while (1) {
        vTaskDelay(1);
    }
}